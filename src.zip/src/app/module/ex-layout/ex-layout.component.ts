import { Component } from '@angular/core';

@Component({
  selector: 'app-ex-layout',
  templateUrl: './ex-layout.component.html',
  styleUrls: ['./ex-layout.component.scss']
})
export class ExLayoutComponent {

}
