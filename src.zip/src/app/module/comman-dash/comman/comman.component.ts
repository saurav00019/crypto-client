import { Component } from '@angular/core';

@Component({
  selector: 'app-comman',
  templateUrl: './comman.component.html',
  styleUrls: ['./comman.component.scss']
})
export class CommanComponent {

}
