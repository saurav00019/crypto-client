import { Component } from '@angular/core';

@Component({
  selector: 'app-p2p-transaction-view',
  templateUrl: './p2p-transaction-view.component.html',
  styleUrls: ['./p2p-transaction-view.component.scss']
})
export class P2pTransactionViewComponent {

}
