import { Component } from '@angular/core';

@Component({
  selector: 'app-p2p-package',
  templateUrl: './p2p-package.component.html',
  styleUrls: ['./p2p-package.component.scss']
})
export class P2pPackageComponent {

}
