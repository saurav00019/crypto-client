import { Component } from '@angular/core';

@Component({
  selector: 'app-ex-market-list',
  templateUrl: './ex-market-list.component.html',
  styleUrls: ['./ex-market-list.component.scss']
})
export class ExMarketListComponent {

}
