import { Component } from '@angular/core';

@Component({
  selector: 'app-invite-earn',
  templateUrl: './invite-earn.component.html',
  styleUrls: ['./invite-earn.component.scss']
})
export class InviteEarnComponent {

}
