import { Component } from '@angular/core';

@Component({
  selector: 'app-myaccount',
  templateUrl: './myaccount.component.html',
  styleUrls: ['./myaccount.component.scss']
})
export class MyaccountComponent {
  active = 1;
  constructor() {
    
   }

  ngOnInit(): void {
  }
}
