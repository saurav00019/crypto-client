import { Component } from '@angular/core';

@Component({
  selector: 'app-ex-customer-list',
  templateUrl: './ex-customer-list.component.html',
  styleUrls: ['./ex-customer-list.component.scss']
})
export class ExCustomerListComponent {

}
