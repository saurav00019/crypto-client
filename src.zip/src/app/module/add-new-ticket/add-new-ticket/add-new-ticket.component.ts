import { Component } from '@angular/core';

@Component({
  selector: 'app-add-new-ticket',
  templateUrl: './add-new-ticket.component.html',
  styleUrls: ['./add-new-ticket.component.scss']
})
export class AddNewTicketComponent {

}
