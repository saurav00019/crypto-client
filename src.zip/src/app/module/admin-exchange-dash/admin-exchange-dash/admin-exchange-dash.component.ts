import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-exchange-dash',
  templateUrl: './admin-exchange-dash.component.html',
  styleUrls: ['./admin-exchange-dash.component.scss']
})
export class AdminExchangeDashComponent {
  active: any = 1;
  active1:any =4;
  active2:any = 6;
}
