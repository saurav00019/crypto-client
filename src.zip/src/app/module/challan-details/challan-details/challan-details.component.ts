import { Component } from '@angular/core';

@Component({
  selector: 'app-challan-details',
  templateUrl: './challan-details.component.html',
  styleUrls: ['./challan-details.component.scss']
})
export class ChallanDetailsComponent {

}
