import { Component } from '@angular/core';


@Component({
  selector: 'app-ex-tradebook-trade',
  templateUrl: './ex-tradebook-trade.component.html',
  styleUrls: ['./ex-tradebook-trade.component.scss']
})
export class ExTradebookTradeComponent {
 
}
