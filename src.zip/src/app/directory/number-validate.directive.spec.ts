import { NumberValidateDirective } from './number-validate.directive';

describe('NumberValidateDirective', () => {
  it('should create an instance', () => {
    // const directive = new NumberValidateDirective();
    // expect(directive).toBeTruthy();
  });
});
