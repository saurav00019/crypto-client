import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PackagePageRoutingModule } from './package-page-routing.module';
import { PackagePageComponent } from './package-page/package-page.component';


@NgModule({
  declarations: [
    PackagePageComponent
  ],
  imports: [
    CommonModule,
    PackagePageRoutingModule
  ]
})
export class PackagePageModule { }
