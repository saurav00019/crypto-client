import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SymbolRoutingModule } from './symbol-routing.module';
import { SymbolComponent } from './symbol/symbol.component';


@NgModule({
  declarations: [
    SymbolComponent
  ],
  imports: [
    CommonModule,
    SymbolRoutingModule
  ]
})
export class SymbolModule { }
