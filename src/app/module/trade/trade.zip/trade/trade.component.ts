import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { ApiDataService } from 'src/app/services/dataservice/api-data.service';

@Component({
  selector: 'app-trade',
  templateUrl: './trade.component.html',
  styleUrls: ['./trade.component.scss']
})
export class TradeComponent implements OnInit {

  active = 1;

  constructor( private modalService: NgbModal, private api : ApiDataService , private toastrService: ToastrService,  private fb: UntypedFormBuilder,) {
  }
  tradeListData: any
  openViewTrade(content: any , va1: any) {
    this.tradeListData =va1
		this.modalService.open(content, { size: 'xl p-two-p-modal1 modal-lg0 ' });
	}

  ngOnInit(){
    this.listOfTrade();
  }



  tradeList: any
  listOfTrade(){
  
    let obj = {
      "Key": "",
      "Order_Trade": 2, // For Order = 1, Trade = 2
      "Profile":1002
  }

    this.api.getTrade(obj).subscribe({
      next: (res: any) => {
      this.tradeList=res.lstTrade
      console.log("this.tradeList",this.tradeList);
      
  
      },
      error: (err: any) => {
        console.log(err);
  
        this.toastrService.error('Server not responding', 'Error');
      },
    });
  }
}
