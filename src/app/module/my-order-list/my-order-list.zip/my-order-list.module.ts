import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MyOrderListRoutingModule } from './my-order-list-routing.module';
import { MyOrderListComponent } from './my-order-list/my-order-list.component';


@NgModule({
  declarations: [
    MyOrderListComponent
  ],
  imports: [
    CommonModule,
    MyOrderListRoutingModule
  ]
})
export class MyOrderListModule { }
