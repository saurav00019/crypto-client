import { map } from 'rxjs/operators';
import { Injectable } from '@angular/core';

import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment'
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { CookieService } from 'ngx-cookie-service';

export interface CheckboxItem {
  Gateway: string;
  GatewayID: number;
  Key: string | null;
  oStatus: number;
}

@Injectable({
  providedIn: 'root'
})
export class GlobalAPIService {
  domain = environment.url;
  data = [];
  

  constructor(private http: HttpClient, private router: Router, private cookieService:CookieService) {

  }
  isLoggedIn() {
    if (this.cookieService.get('loginData')) {

      return true
    }
    else {

      return false
    }
  }
  // https://api.brcmarkets.com/Tradersroom_API_brcmarkets/LOGIN_USER?Email=suraj.bhardwaj@marketwicks.com&Password=a&DealerId=1001
  login(obj: any) {
    return this.http.get(this.domain + 'LOGIN_USER', { params: obj }).pipe(map(res => { return res }));
  }
  getKycset(kycSettingParams:any){
  return this.http.get(this.domain + 'GET_KYC_SETTINGS', { params: kycSettingParams }).pipe(map(res => { return res }));
}
  getSharedData(data:any) {
    return this.http.get(data);
  }
  // getSharedData(obj:any){
   
  //   return this.http.get(this.domain + 'GET_ALL_USER_PROFILE_v3?',{params:obj}).pipe(map(res => { return res }));
  // }
  // getUserListData(){
   
  //   return this.http.get(this.domain + 'GET_ALL_USER_PROFILE_v3?Affiliate=0&DealerID=1001&Count=1&Index=10').pipe(map(res => { return res }));
  // }

  // ========================================================================== gateway ==================================================================
  addGateway(obj: any){
    return this.http.post(this.domain + 'ADD_P2P_GATEWAY',obj);
  }
  deleteGateway(obj: any){
    return this.http.post(this.domain + 'DEL_P2P_GATEWAY',obj);
  }
 
  getGatewayData(){
    return this.http.get(this.domain + 'GET_P2P_GATEWAY');
  }

  // ========================================================================== order-book ==================================================================
  
  getOrder(){
    return this.http.get(this.domain + 'GET_P2P_POSITION');
  }
  
  // ==========================================================================  trade-book ==================================================================

  getTrade(obj: any){
    return this.http.get(this.domain + 'GET_P2P_TRADE',{params: obj});
  }

  // ========================================================================== packages =====================================================================

  getPackage() {
    return this.http.get(this.domain + 'GET_P2P_ADM_PACKAGES')
  }

  addPakage(obj: any){
    return this.http.post(this.domain + "ADD_P2P_ADM_PACKAGE", obj)
  }

  deletePackage(obj: any) {
    return this.http.post(this.domain + "DEL_P2P_ADM_PACKAGES", obj)
  }
  
  // ========================================================================== Symbols ======================================================================

  //Add Crypto Or Symbol
  addSymbol(obj: any) {
    return this.http.post(this.domain + 'ADD_P2P_ADM_CRYPTO',obj)
  }

  //Get Crypto Or Symbol list Data
  getCryptoSymbol() {
    return this.http.get(this.domain + 'GET_P2P_ADM_CRYPTO')
  }

  //Delete Crypto Or Symbol 
  deleteCryptoSymbol(obj: any) {
    return this.http.post(this.domain + 'DEL_P2P_ADM_CRYPTO',obj)
  }
  
  //Update Crypto Or Symbol Status  
  updateStatus(obj: any) {
    return this.http.post(this.domain + 'UPDATE_P2P_ADM_CRYPTO_STATUS',obj)
  }

  //Update Crypto Or Symbol Info
  updateInfo(obj: any){
    return this.http.post(this.domain + 'UPDATE_P2P_ADM_CRYPTO_INFO',obj)
  }
  
  getTransaction(obj: any) {
    return this.http.get(this.domain + "GET_P2P_ADM_TRANS_REQ", {params: obj})
  }

  // ========================================================================== User List ======================================================================

  getUserList(obj: any) {
    return this.http.post(this.domain + "GET_ADM_USERS", obj)
  }
  
  // ========================================================================== Challen ====================================================================== 
  getChaReqId(obj: any) {
  return this.http.post(this.domain + "GET_P2P_CHALLEN_REQ_BY_ID", obj)
  }
 
}
